<?php
require_once 'authCheck.php';
?>

<!DOCTYPE html>
<html lang="en">

    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">

        <title>Vellum Trading - Portfolio</title>

        <link rel="stylesheet" href="style.css">
    </head>

    <body> 
        <nav>
            <h2>Vellum Trading</h2>

            <div> 
                <a href="index.php">Home</a>
                <a href="dashboard.php">Dashboard</a>
                <a href="search.php">Search Stocks</a>
                <a href="portfolio.php">Portfolio</a>
                <a href="transactions.php">Transactions</a>
                <a href="logout.php">Logout</a>
            </div>

        </nav>

        <main>

        <h1>My Portfolio</h1>

            <section>
                <h2>Portfolio Value</h2>
                <p>$10,000.00</p> 
                <!-- Placeholder value; replace with actual portfolio data. -->
            </section>

            <section>
                <h2>Holdings</h2>

                <table>

                    <tr>
                        <th>Stock</th>
                        <th>Shares</th>
                        <th>Price</th>
                        <th>Value</th>
                    </tr>

                    <!-- backend stuff goes here -->

                </table>
            </section>

        </main>

    </body>

</html>
